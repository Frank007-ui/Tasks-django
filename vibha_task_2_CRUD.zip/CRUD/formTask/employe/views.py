from django.shortcuts import render, redirect, get_object_or_404
from .models import Employe
from .forms import EmployeForm

# List
def employe_list(request):
    employes = Employe.objects.all()
    return render(request, 'employe/employe_list.html', {'employes': employes})

# Create
def employe_create(request):
    form = EmployeForm(request.POST or None)
    if form.is_valid():
        form.save()
        return redirect('employe_list')
    return render(request, 'employe/employe_form.html', {'form': form})

# Update
def employe_update(request, id):
    emp = get_object_or_404(Employe, id=id)
    form = EmployeForm(request.POST or None, instance=emp)
    if form.is_valid():
        form.save()
        return redirect('employe_list')
    return render(request, 'employe/employe_form.html', {'form': form})

# Delete
def employe_delete(request, id):
    emp = get_object_or_404(Employe, id=id)
    if request.method == "POST":
        emp.delete()
        return redirect('employe_list')
    return render(request, 'employe/employe_confirm_delete.html', {'employe': emp})
from django.urls import path
from . import views

urlpatterns = [
    path('', views.employe_list, name='employe_list'),
    path('create/', views.employe_create, name='employe_create'),
    path('update/<int:id>/', views.employe_update, name='employe_update'),
    path('delete/<int:id>/', views.employe_delete, name='employe_delete'),
]
from django.urls import path
from . import views

urlpatterns = [
    path('create/', views.create_employee, name='create'),
    path('read/', views.read_employee, name='read'),
    path('update/<int:id>/', views.update_employee, name='update'),
    path('delete/<int:id>/', views.delete_employee, name='delete'),
]

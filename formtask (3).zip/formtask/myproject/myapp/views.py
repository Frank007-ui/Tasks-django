from django.shortcuts import render, redirect, get_object_or_404
from .models import Employee
from .forms import EmployeeForm

# Create
def create_employee(request):
    form = EmployeeForm()
    if request.method == "POST":
        form = EmployeeForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('read')
    return render(request, 'create.html', {'form': form})

# Read
def read_employee(request):
    employees = Employee.objects.all()
    return render(request, 'read.html', {'employees': employees})

# Update
def update_employee(request, id):
    emp = get_object_or_404(Employee, id=id)
    form = EmployeeForm(instance=emp)
    if request.method == "POST":
        form = EmployeeForm(request.POST, instance=emp)
        if form.is_valid():
            form.save()
            return redirect('read')
    return render(request, 'update.html', {'form': form})

# Delete
def delete_employee(request, id):
    emp = get_object_or_404(Employee, id=id)
    emp.delete()
    return redirect('read')
